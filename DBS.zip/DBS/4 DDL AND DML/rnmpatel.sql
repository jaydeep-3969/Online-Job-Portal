drop table js_achievement;
drop table js_experience;
drop table js_academic;
drop table js_project;
drop table js_reference;
drop table js_skill;
drop table js_activity;
drop table js_saved_job;
drop table js_applied_job;
drop table js_referred_job;
drop table jp_master;
drop table jp_job;


drop SEQUENCE user_id;
drop SEQUENCE role_id;
drop SEQUENCE con_id;
drop SEQUENCE req_id;
drop SEQUENCE not_id;
drop SEQUENCE type_id;
drop SEQUENCE achieve_id;
drop SEQUENCE academic_id;
drop SEQUENCE exp_id;
drop SEQUENCE project_id;
drop SEQUENCE ref_id;
drop SEQUENCE skill_id;
drop SEQUENCE activity_id;
drop SEQUENCE job_id;

/*-----------------------------------------------------------*/



CREATE SEQUENCE role_id INCREMENT BY 1;

CREATE TABLE role (
  role_id 		int 		NOT NULL PRIMARY KEY,
  role_type 	varchar(10)	NOT NULL
);


/*-----------------------------------------------------------*/

CREATE SEQUENCE user_id INCREMENT BY 1;


CREATE TABLE credential (
  user_id	NUMBER(38)  PRIMARY KEY,
  username 	varchar(15)	NOT NULL,
  pw 	varchar(15)	NOT NULL,
  seq_que 	varchar(50)	NOT NULL,
  ans 		varchar(20) NOT NULL,
  role_id 	NUMBER(10) 		NOT NULL,
  CONSTRAINT FK_cred_role FOREIGN KEY(role_id) REFERENCES role(role_id),
  CONSTRAINT con_user_id CHECK(REGEXp_LIKE(username,'\w[a-z:A-Z:0-9]{5,10}'))
);


/*--------------------------------------------------------*/

CREATE TABLE js_master (
  js_user_id	 NUMBER(38)	 PRIMARY KEY,
  fname			 varchar(50)	NOT NULL,
  mname		     varchar(50)	NOT NULL,
  lname			 varchar(50)	NOT NULL,
  profile_photo_url varchar(1000)	NULL,
  mobile_no		 varchar(10)	NULL,
  email			 varchar(50)	NOT NULL,
  gender 		 NUMBER(1)		NOT NULL,
  city			 varchar(20)	NULL,
  state			 varchar(20)	NULL,
  pincode		 varchar(6)		NULL,
  street		 varchar(50)	NULL,
  landmark	 	 varchar(50)	NULL,
  is_fresher	 NUMBER(38)			NOT NULL,
  date_of_birth  date,
  age 			 NUMBER(38),
  CONSTRAINT FK_cred_js FOREIGN KEY(js_user_id) REFERENCES credential(user_id)
);



/*-------------------------------------------------------------*/


CREATE SEQUENCE con_id INCREMENT BY 1;

CREATE TABLE js_connection (
  con_id		 int 	NOT NULL PRIMARY KEY,
  src_user_id int	NOT NULL,
  des_user_id int	NOT NULL
);

SELECT * FROM JS_CONNECTION;
/*-------------------------------------------------------------*/

CREATE SEQUENCE req_id INCREMENT BY 1;

CREATE TABLE request (
  req_id 		number(38)	NOT NULL PRIMARY KEY,
  src_user_id 	number(38)	NOT NULL,
  dest_user_id 	number(38)	NOT NULL,
  CONSTRAINT FK_number_q_src_js FOREIGN KEY(src_user_id) REFERENCES js_master(js_user_id),
  CONSTRAINT FK_req_dest_js FOREIGN KEY(dest_user_id) REFERENCES js_master(js_user_id)
);


/* ----------------------------------------*/

CREATE SEQUENCE type_id INCREMENT BY 1;

CREATE TABLE not_type (
  type_id	int 		PRIMARY KEY NOT NULL,
  type_nm	varchar(25) NOT NULL
);

-------------js_notification table-------------    --                                       ---------------------- --
CREATE SEQUENCE not_id INCREMENT BY 1;

CREATE TABLE js_notification (
  not_id 		number(38) 		NOT NULL PRIMARY KEY,
  type_id		number(38) 		NOT NULL,
  time_stamp	timestamp	NOT NULL,
  js_user_id	number(38)			NOT NULL,
  is_open		number(1)			NOT NULL,
  CONSTRAINT FK_not_type FOREIGN KEY(type_id) REFERENCES js_master(type_id),
  CONSTRAINT FK_not_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

-------------Accept_Not Table-------------
CREATE TABLE accept_not (
  not_id 		number(38) 		NOT NULL PRIMARY KEY,
  src_user_id 	number(38)			NOT NULL,
  CONSTRAINT FK_not_accept FOREIGN KEY(type_id) REFERENCES js_notification(not_id)
);


-------------js_academic table-------------

drop table js_academic;
CREATE SEQUENCE academic_id INCREMENT BY 1;


CREATE TABLE js_academic (
  academic_id 		number(38)			NOT NULL PRIMARY KEY,
  institute_name	varchar(50)	NOT NULL,
  degree 			varchar(50)	NOT NULL,
  is_percentage 	number(1)		NOT NULL,
  mark 				number(38)	NOT NULL,
  pr 				number(38)		NULL,
  branch 			varchar(50)		NULL,
  passing_year 		numeric(4,0) NOT NULL,
  js_user_id 		number(38)			NOT NULL,
  CONSTRAINT FK_academic_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

-------------js_skill table-------------
drop sequence skill_id;
CREATE SEQUENCE skill_id INCREMENT BY 1;

CREATE TABLE js_skill (

 skill_id 		number(38)			NOT NULL PRIMARY KEY,
  skill 		varchar(200)	NOT NULL,
  js_user_id 	number(38)				NOT NULL,
  CONSTRAINT FK_skill_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

/* ----------------------------------------*/


CREATE SEQUENCE pref_id INCREMENT BY 1;

CREATE TABLE js_preference (
  pref_id 		number(38)	NOT NULL PRIMARY KEY,
  industry1		varchar(50)	NULL,
  industry2		varchar(50)	NULL,
  industry3		varchar(50)	NULL,
  location1		varchar(50)	NULL,
  location2		varchar(50)	NULL,
  location3		varchar(50)	NULL,
  designation1	varchar(50)	NULL,
  designation2	varchar(50)	NULL,
  designation3	varchar(50)	NULL,
  min_salary 	number(38) NULL,
  max_salary 	number(38) NULL,
  startup 		number(1) default 0,
  min_size_in_emp number(38),
  js_user_id number(38) not null,
  CONSTRAINT FK_exp_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

-------------js_experience table-------------                                    ------------------------------------
CREATE SEQUENCE exp_id INCREMENT BY 1;


CREATE TABLE js_experience (
  exp_id 			number(38)			NOT NULL PRIMARY KEY,
  institute_name	varchar(50)	NOT NULL,	
  designation 		varchar(50)	NOT NULL,
  is_working		number(1)		NOT NULL,
  exp_from 				date		NOT NULL,
  exp_to 				date		NULL,
  year_exp			number(1)		NOT NULL,
  achievement 		varchar(1000)	NULL,
  js_user_id 		number(38)			NOT NULL,
  CONSTRAINT FK_exp_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);


-------------js_project table-------------
CREATE SEQUENCE proj_id INCREMENT BY 1;

CREATE TABLE js_project (
  project_id 	int 		NOT NULL PRIMARY KEY,
  title 		varchar(50)	NOT NULL,
  description 	varchar(2000)	NULL,
  team_size		int			NOT NULL,
  role 			varchar(50)		NULL,
  duration 		varchar(50)	NOT NULL,
  js_user_id 	int			NOT NULL,
  CONSTRAINT FK_proj_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

-------------js_achievement table-------------
CREATE SEQUENCE achieve_id INCREMENT BY 1;

CREATE TABLE js_achievement (
  achieve_id 	number(38) 			NOT NULL PRIMARY KEY,
  achieved 		varchar(1000)	NOT NULL,
  js_user_id	number(38)				NOT NULL,
  CONSTRAINT FK_achieve_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);



-------------js_activity table-------------
CREATE SEQUENCE activity_id INCREMENT BY 1;

CREATE TABLE js_activity (
  activity_id 	number(38) 			NOT NULL PRIMARY KEY,
  activity		varchar(1000)	NOT NULL,
  js_user_id	number(38)				NOT NULL,
  CONSTRAINT FK_activity_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

-------------js_reference table-------------
CREATE SEQUENCE ref_id INCREMENT BY 1;

CREATE TABLE js_reference (
  ref_id			 number(38) 			NOT NULL PRIMARY KEY,
  name 				 varchar(50)	NOT NULL,
  designation		 varchar(50)	NOT NULL,
  institute_name	 varchar(50)	NULL,
  mobile_no			 varchar(10)	NULL,
  email				 varchar(100)	NOT NULL,
  js_user_id		 number(38) 			NOT NULL,
  CONSTRAINT FK_ref_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);


-------------jp_master table-------------                                           -------------------------------------
CREATE TABLE jp_master (
  jp_user_id 			number(38) NOT NULL PRIMARY KEY,
  profile_photo_url 	varchar2(200)	NULL,
  company_name			varchar2(15)		NOT NULL,
  industry 				varchar2(100)	NOT NULL,
  size_in_emp 			number(38)				NOT NULL,
  description 			nchar(5000)	NULL,
  website_url 			nCHAR(500)	NOT NULL,
  about 				nCHAR(2000)	NULL,
  founded_on_year		numeric(4,0)	NULL,
  street 				nchar(100)	NULL,
  landmark 				varchar2(50)		NULL,
  city 					varchar2(20)		NULL,
  state 				varchar2(20)		NULL,
  pincode 				varchar2(6)		NULL,
  contact_person 		VARCHAR2(100)	NOT NULL,
  mobile_no 			varchar2(10)		NULL,
  email 				varchar2(100)	NOT NULL,
  CONSTRAINT FK_cred_js FOREIGN KEY(js_user_id) REFERENCES credential(user_id)
);

-------------jp_job table-------------      ----------------------------------------------------
CREATE SEQUENCE job_id INCREMENT BY 1;

CREATE TABLE jp_job (
  job_id 		number(38) 		NOT NULL PRIMARY KEY,
  designation 	varchar(50)	NOT NULL,
  job_descr 	varchar(2000)	NULL,
  vacancy 		number(38)	NOT NULL,
  age_min 		numeric(2,0)	NULL,
  age_max 		numeric(2,0)	NULL,
  salary_avg 	number(38)				NULL,
  exp_year 		numeric(2,0)	NULL,
  jp_user_id 	number(38)			NOT NULL,
  post_date 	date		NOT NULL,
  due_date 		date		NOT NULL,
  venue_desc 	varchar(2000)	NULL,
 
  CONSTRAINT FK_job_jp FOREIGN KEY(jp_user_id) REFERENCES credential(jp_user_id)
);



-------------js_referred_job table-------------
CREATE TABLE js_referred_job (
  con_id 			number(38) NOT NULL PRIMARY KEY,
  job_id 			number(38)	NOT NULL,
  referred_by_id 	number(38)	NOT NULL,
  CONSTRAINT FK_refej_con FOREIGN KEY(con_id) REFERENCES js_connection(con_id),
  CONSTRAINT FK_refej_job FOREIGN KEY(job_id) REFERENCES jp_job(job_id),
  PRIMARY KEY (js_user_id,job_id)
);
	
-------------js_approved_job table-------------                                      -----------------------------
CREATE TABLE js_approved_job (
  js_user_id 	int NOT NULL PRIMARY KEY,
  job_id 		int	NOT NULL,
  CONSTRAINT FK_approvej_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
  CONSTRAINT FK_approvej_job FOREIGN KEY(job_id) REFERENCES jp_job(job_id)

);

-------------js_saved_job table-------------
CREATE TABLE js_saved_job (
  js_user_id number(38) NOT NULL,
  job_id 	 number(38) NOT NULL,
  CONSTRAINT FK_savej_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
  CONSTRAINT FK_savej_job FOREIGN KEY(job_id) REFERENCES jp_job(job_id),
  PRIMARY KEY (js_user_id,job_id)
);




-------------------------------------------------------------------------------------------


