drop table credential;
drop table role;
drop table js_master;
drop table js_connection;
drop table request;
drop table js_notification;
drop table not_type;
drop table accept_not;
drop table js_achievement;
drop table js_experience;
drop table js_academic;
drop table js_project;
drop table js_reference;
drop table js_skill;
drop table js_activity;
drop table js_saved_job;
drop table js_applied_job;
drop table js_referred_job;
drop table jp_master;
drop table jp_job;


drop SEQUENCE user_id;
drop SEQUENCE role_id;
drop SEQUENCE con_id;
drop SEQUENCE req_id;
drop SEQUENCE not_id;
drop SEQUENCE type_id;
drop SEQUENCE achieve_id;
drop SEQUENCE academic_id;
drop SEQUENCE exp_id;
drop SEQUENCE project_id;
drop SEQUENCE ref_id;
drop SEQUENCE skill_id;
drop SEQUENCE activity_id;
drop SEQUENCE job_id;

-------------credential table-------------
CREATE SEQUENCE user_id INCREMENT BY 1;

CREATE TABLE credential (
  user_id	int			NOT NULL PRIMARY KEY,
  username 	varchar(15)	NOT NULL,
  password 	varchar(15)	NOT NULL,
  seq_que 	varchar(50)	NOT NULL,
  ans 		varchar(20) NOT NULL,
  role_id 	int 		NOT NULL,
  CONSTRAINT FK_cred_role FOREIGN KEY(role_id) REFERENCES js_role(role_id)
);

-------------js_role table-------------
CREATE SEQUENCE role_id INCREMENT BY 1;

CREATE TABLE role (
  role_id 		int 		NOT NULL PRIMARY KEY,
  role_type 	varchar(10)	NOT NULL
);

-------------js_master table-------------

CREATE TABLE js_master (
  js_user_id	 int		 	NOT NULL PRIMARY KEY,
  fname			 varchar(50)	NOT NULL,
  mname		     varchar(50)	NOT NULL,
  lname			 varchar(50)	NOT NULL,
  profile_photo_url varchar(1000)	NULL,
  mobile_no		 varchar(10)	NULL,
  email			 varchar(50)	NOT NULL,
  gender 		 tinyint		NOT NULL,
  city			 varchar(20)	NULL,
  state			 varchar(20)	NULL,
  pincode		 varchar(6)		NULL,
  street		 varchar(50)	NULL,
  landmark	 	 varchar(50)	NULL,
  is_fresher	 int			NOT NULL,
  date_of_birth  date,
  age 			 int,
  CONSTRAINT FK_cred_js FOREIGN KEY(js_user_id) REFERENCES credential(user_id)
);

-------------js_connection table-------------
CREATE SEQUENCE con_id INCREMENT BY 1;

CREATE TABLE js_connection (
  con_id		 int 	NOT NULL PRIMARY KEY,
  src_user_id int	NOT NULL,
  des_user_id int	NOT NULL
);

-------------request table-------------
CREATE SEQUENCE req_id INCREMENT BY 1;

CREATE TABLE request (
  req_id 		int	NOT NULL PRIMARY KEY,
  src_user_id 	int	NOT NULL,
  dest_user_id 	int	NOT NULL,
  CONSTRAINT FK_req_src_js FOREIGN KEY(src_user_id) REFERENCES js_master(js_user_id),
  CONSTRAINT FK_req_dest_js FOREIGN KEY(dest_user_id) REFERENCES js_master(js_user_id)
);

-------------not_type table-------------
CREATE SEQUENCE type_id INCREMENT BY 1;

CREATE TABLE not not_type (
  type_id	int 		PRIMARY KEY NOT NULL,
  type_nm	varchar(25) NOT NULL
);
-------------js_notification table-------------
CREATE SEQUENCE not_id INCREMENT BY 1;

CREATE TABLE js_notification (
  not_id 		int 		NOT NULL PRIMARY KEY,
  type_id		int 		NOT NULL,
  time_stamp	timestamp	NOT NULL,
  js_user_id	int			NOT NULL,
  is_open		int			NOT NULL,
  CONSTRAINT FK_not_type FOREIGN KEY(type_id) REFERENCES js_master(type_id),
  CONSTRAINT FK_not_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

-------------Accept_Not Table-------------
CREATE TABLE accept_not (
  not_id 		int 		NOT NULL PRIMARY KEY,
  src_user_id 	int			NOT NULL,
  CONSTRAINT FK_not_accept FOREIGN KEY(type_id) REFERENCES js_notification(not_id)
);


-------------js_academic table-------------
CREATE SEQUENCE academic_id INCREMENT BY 1;

CREATE TABLE js_academic (
  academic_id 		int			NOT NULL PRIMARY KEY,
  institute_name	varchar(50)	NOT NULL,
  degree 			varchar(50)	NOT NULL,
  is_percentage 	tinyint		NOT NULL,
  mark 				int			NOT NULL,
  pr 				int				NULL,
  branch 			varchar(50)		NULL,
  passing_year 		numeric(4,0)NOT NULL,
  js_user_id 		int			NOT NULL,
  CONSTRAINT FK_academic_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
);

-------------js_skill table-------------
CREATE SEQUENCE skill_id INCREMENT BY 1;

CREATE TABLE js_skill (
  skill _id 	int 			NOT NULL PRIMARY KEY,
  skill 		varchar(200)	NOT NULL,
  js_user_id 	int				NOT NULL,
  CONSTRAINT FK_skill_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
);

-------------js_preference table-------------
CREATE SEQUENCE pref_id INCREMENT BY 1;

CREATE TABLE js_preference (
  pref_id 		int	NOT NULL PRIMARY KEY,
  industry1		varchar(50)	NULL,
  industry2		varchar(50)	NULL,
  industry3		varchar(50)	NULL,
  location1		varchar(50)	NULL,
  location2		varchar(50)	NULL,
  location3		varchar(50)	NULL,
  designation1	varchar(50)	NULL,
  designation2	varchar(50)	NULL,
  designation3	varchar(50)	NULL,
  min_salary 	long NULL,
  max_salary 	long NULL,
  startup 		tinyint default 0,
  min_size_in_emp int
  CONSTRAINT FK_exp_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
);

-------------js_experience table-------------
CREATE SEQUENCE exp_id INCREMENT BY 1;

CREATE TABLE js_experience (
  exp_id 			int			NOT NULL PRIMARY KEY,
  institute_name	varchar(50)	NOT NULL,	
  designation 		varchar(50)	NOT NULL,
  is_working		tinyint		NOT NULL,
  from 				date		NOT NULL,
  to 				date		NULL,
  year_exp			tinyint		NOT NULL,
  achievement 		varchar(1000)	NULL,
  js_user_id 		int			NOT NULL,
  CONSTRAINT FK_exp_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
);

-------------js_project table-------------
CREATE SEQUENCE proj_id INCREMENT BY 1;

CREATE TABLE js_project (
  project_id 	int 		NOT NULL PRIMARY KEY,
  title 		varchar(50)	NOT NULL,
  description 	varchar(2000)	NULL,
  team_size		int			NOT NULL,
  role 			varchar(50)		NULL,
  duration 		varchar(50)	NOT NULL,
  js_user_id 	int			NOT NULL,
  CONSTRAINT FK_proj_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
);

-------------js_achievement table-------------
CREATE SEQUENCE achieve_id INCREMENT BY 1;

CREATE TABLE js_achievement (
  achieve_id 	int 			NOT NULL PRIMARY KEY,
  achieved 		varchar(1000)	NOT NULL,
  js_user_id	int				NOT NULL,
  CONSTRAINT FK_achieve_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
);



-------------js_activity table-------------
CREATE SEQUENCE activity_id INCREMENT BY 1;

CREATE TABLE js_activity (
  activity_id 	int 			NOT NULL PRIMARY KEY,
  activity		varchar(1000)	NOT NULL,
  js_user_id	int				NOT NULL,
  CONSTRAINT FK_activity_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
);

-------------js_reference table-------------
CREATE SEQUENCE ref_id INCREMENT BY 1;

CREATE TABLE js_reference (
  ref_id			 int 			NOT NULL PRIMARY KEY,
  name 				 varchar(50)	NOT NULL,
  designation		 varchar(50)	NOT NULL,
  institute_name	 varchar(50)	NULL,
  mobile_no			 varchar(10)	NULL,
  email				 varchar(100)	NOT NULL,
  js_user_id		 int 			NOT NULL,
  CONSTRAINT FK_ref_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id)
);

-------------js_referred_job table-------------
CREATE TABLE js_referred_job (
  con_id 			int NOT NULL PRIMARY KEY,
  job_id 			int	NOT NULL,
  referred_by_id 	int	NOT NULL,
  CONSTRAINT FK_refej_con FOREIGN KEY(con_id) REFERENCES js_connection(con_id),
  CONSTRAINT FK_refej_job FOREIGN KEY(job_id) REFERENCES jp_job(job_id),
  PRIMARY KEY (js_user_id,job_id)
);
	
-------------js_approved_job table-------------
CREATE TABLE js_approved_job (
  js_user_id 	int NOT NULL PRIMARY KEY,
  job_id 		int	NOT NULL,
  CONSTRAINT FK_approvej_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
  CONSTRAINT FK_approvej_job FOREIGN KEY(job_id) REFERENCES jp_job(job_id),
  PRIMARY KEY (js_user_id,job_id)
);

-------------js_saved_job table-------------
CREATE TABLE js_saved_job (
  js_user_id int NOT NULL,
  job_id 	 int NOT NULL,
  CONSTRAINT FK_savej_js FOREIGN KEY(js_user_id) REFERENCES js_master(js_user_id),
  CONSTRAINT FK_savej_job FOREIGN KEY(job_id) REFERENCES jp_job(job_id),
  PRIMARY KEY (js_user_id,job_id)
);





-------------jp_master table-------------
CREATE TABLE jp_master (
  jp_user_id 			int NOT NULL PRIMARY KEY,
  profile_photo_url 	varchar(200)	NULL,
  company_name			varchar(15)		NOT NULL,
  industry 				varchar(100)	NOT NULL,
  size_in_emp 			int				NOT NULL,
  description 			varchar(5000)	NULL,
  website_url 			varchar(500)	NOT NULL,
  about 				varchar(2000)	NULL,
  founded_on_year		numeric(4,0)	NULL,
  street 				varchar(100)	NULL,
  landmark 				varchar(50)		NULL,
  city 					varchar(20)		NULL,
  state 				varchar(20)		NULL,
  pincode 				varchar(6)		NULL,
  contact_person 		varchar(100)	NOT NULL,
  mobile_no 			varchar(10)		NULL,
  email 				varchar(100)	NOT NULL,
  CONSTRAINT FK_cred_js FOREIGN KEY(js_user_id) REFERENCES credential(user_id)
);

-------------jp_job table-------------
CREATE SEQUENCE job_id INCREMENT BY 1;

CREATE TABLE jp_job (
  job_id 		int 		NOT NULL PRIMARY KEY,
  designation 	varchar(50)	NOT NULL,
  job_descr 	varchar(2000)	NULL,
  vacancy 		smallint	NOT NULL,
  age_min 		numeric(2,0)	NULL,
  age_max 		numeric(2,0)	NULL,
  salary_avg 	int				NULL,
  exp_year 		numeric(2,0)	NULL,
  jp_user_id 	int			NOT NULL,
  post_date 	date		NOT NULL,
  due_date 		date		NOT NULL,
  venue_desc 	varchar(2000)	NULL,
  CONSTRAINT FK_job_jp FOREIGN KEY(jp_user_id) REFERENCES credential(jp_user_id)
);

-------------End-------------



